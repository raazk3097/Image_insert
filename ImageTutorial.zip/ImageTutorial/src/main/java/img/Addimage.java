 package img;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.*;
import java.sql.DriverManager;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;


@MultipartConfig
public class Addimage extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		System.out.println("in do post method of add  Image Servlet");
		Part file= request.getPart("image");
		
		String imageFileName= file.getSubmittedFileName(); //get selected image filename
		System.out.println("select Image File name"+imageFileName);
		//String uploadPath="C:/Users/DELL/OneDrive/Desktop/MyProject/ImageTutorial/Images/"+imageFileName;  //upload path where we have to upload our actual image
		String uploadPath="C:/Users/DELL/OneDrive/Desktop/MyProject/ImageTutorial/src/main/webapp/Images/"+imageFileName;
//		C:\Users\DELL\OneDrive\Desktop\MyProject\ImageTutorial\src\main\webapp\Images
		System.out.println("upload path"+uploadPath);
		
		FileOutputStream fos= new FileOutputStream(uploadPath);
		InputStream is= file.getInputStream();
		
		//uploading our selected image into images folder
		
		try {
			byte[] data= new byte[is.available()];
			is.read(data);
			fos.write(data);
			fos.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		//getting database connection (jdbc code)
		Connection con=null;
		PreparedStatement ps;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			 con= DriverManager.getConnection("jdbc:mysql://localhost:3306/imageTutorial","root","boot");
			 String query= "insert into image(imageFileName)values(?)";
			 ps=con.prepareStatement(query);
			 ps.setString(1, imageFileName);
			 int n= ps.executeUpdate();
			 if(n>0) {
				 System.out.println("Image Added successfully");
			 }else {
				 System.out.println("failed to upload image");
			 }
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
