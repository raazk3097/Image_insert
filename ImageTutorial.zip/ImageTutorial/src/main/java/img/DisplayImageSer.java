 package img;

import java.io.IOException;

import java.sql.*;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class DisplayImageSer extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("in do post method of Display  Image Servlet");
		String imageId= request.getParameter("imageId");
		int id=Integer.parseInt(imageId);
		
		//database connection
		Connection con=null;
		Statement stmt;
		int imgId=0;
		String imgFileName=null;
		
		try {
			 Class.forName("com.mysql.cj.jdbc.Driver");
			 con= DriverManager.getConnection("jdbc:mysql://localhost:3306/imageTutorial","root","boot");
			 String query= "select*from image";
			 stmt= con.createStatement();
			 ResultSet rs= stmt.executeQuery(query);
			 while(rs.next()) {
				 if(rs.getInt("imageId")==id) {
					 imgId= rs.getInt("imageId");
					 imgFileName= rs.getString("imageFileName");
				 }
			 }
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		RequestDispatcher rd;
		request.setAttribute("id", String.valueOf(imgId));
		request.setAttribute("img",imgFileName);
		rd=request.getRequestDispatcher("displayImage.jsp");
		rd.forward(request, response);
	}

}
  